-- Consulta 6 · RANKING con QUALIFY: los 3 años más cálidos de cada estación
-- (solo años con >= 300 días de datos) y su anomalía vs. 1991-2020.
WITH anual AS (
    SELECT nombre, anio, AVG(tavg) AS tavg_anual
    FROM clima
    WHERE tavg IS NOT NULL
    GROUP BY nombre, anio
    HAVING COUNT(tavg) >= 300
),
referencia AS (
    SELECT nombre, AVG(tavg_anual) AS normal_1991_2020
    FROM anual
    WHERE anio BETWEEN 1991 AND 2020
    GROUP BY nombre
)
SELECT a.nombre,
       RANK() OVER (PARTITION BY a.nombre ORDER BY a.tavg_anual DESC) AS puesto,
       a.anio,
       ROUND(a.tavg_anual, 2)                          AS tavg_c,
       ROUND(a.tavg_anual - r.normal_1991_2020, 2)     AS anomalia_c
FROM anual a
JOIN referencia r USING (nombre)
QUALIFY puesto <= 3
ORDER BY a.nombre, puesto;

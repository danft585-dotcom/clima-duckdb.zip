-- Consulta 2 · PROMEDIOS: climatología mensual (temperatura media, °C)
-- para el período de referencia 1991-2020, en formato tabla cruzada (PIVOT).
-- Solo se usan meses con al menos 20 días válidos, para no sesgar el promedio.
WITH mensual AS (
    SELECT nombre, anio, mes, AVG(tavg) AS tavg_mes
    FROM clima
    WHERE anio BETWEEN 1991 AND 2020
      AND tavg IS NOT NULL
    GROUP BY nombre, anio, mes
    HAVING COUNT(tavg) >= 20
)
PIVOT (
    SELECT nombre,
           strftime(make_date(2000, mes, 1), '%m') AS mes,
           ROUND(AVG(tavg_mes), 1)                AS t
    FROM mensual
    GROUP BY nombre, mes
)
ON mes
USING first(t)
ORDER BY nombre;

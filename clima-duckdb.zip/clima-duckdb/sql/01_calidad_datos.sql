-- Consulta 1 · CONTEOS: cobertura y calidad de datos por estación.
-- Compara registros crudos vs. válidos tras la limpieza.
SELECT
    c.nombre,
    MIN(c.fecha)                                         AS desde,
    MAX(c.fecha)                                         AS hasta,
    COUNT(*)                                             AS dias_registrados,
    COUNT(c.tmax)                                        AS tmax_validos,
    COUNT(*) - COUNT(c.tmax)                             AS tmax_nulos,
    ROUND(100.0 * COUNT(c.tavg) / COUNT(*), 1)           AS pct_tavg_disponible,
    SUM(CASE WHEN c.tavg_imputada THEN 1 ELSE 0 END)     AS tavg_imputadas
FROM clima c
GROUP BY c.nombre
ORDER BY desde;

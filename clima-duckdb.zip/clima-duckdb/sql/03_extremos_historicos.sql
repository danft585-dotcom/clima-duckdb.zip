-- Consulta 3 · MÁXIMOS/MÍNIMOS HISTÓRICOS por estación, con la fecha en que
-- ocurrieron (arg_max / arg_min evitan un self-join).
SELECT
    nombre,
    MAX(tmax)                   AS record_max_c,
    arg_max(fecha, tmax)        AS fecha_record_max,
    MIN(tmin)                   AS record_min_c,
    arg_min(fecha, tmin)        AS fecha_record_min,
    MAX(prcp_mm)                AS lluvia_max_dia_mm,
    arg_max(fecha, prcp_mm)     AS fecha_lluvia_max
FROM clima
GROUP BY nombre
ORDER BY record_max_c DESC;

-- Consulta 4 · FILTRADO COMPLEJO: tendencia de temperatura por década.
-- 1) Se calcula la media anual solo de años "completos" (>= 300 días con tavg).
-- 2) Se agregan por década y solo se aceptan décadas con >= 8 años completos.
-- 3) Con LAG() se obtiene el cambio respecto de la década anterior.
-- 4) Con una regresión lineal (regr_slope) sobre 1971-hoy se estima °C/década.
WITH anual AS (
    SELECT nombre, anio, AVG(tavg) AS tavg_anual
    FROM clima
    WHERE tavg IS NOT NULL
    GROUP BY nombre, anio
    HAVING COUNT(tavg) >= 300
),
decadas AS (
    SELECT nombre,
           (anio // 10) * 10        AS decada,
           AVG(tavg_anual)          AS tavg_decada,
           COUNT(*)                 AS anios_completos
    FROM anual
    GROUP BY nombre, decada
    HAVING COUNT(*) >= 8
),
pendiente AS (
    SELECT nombre,
           ROUND(regr_slope(tavg_anual, anio) * 10, 2) AS tendencia_c_por_decada_1971_hoy
    FROM anual
    WHERE anio >= 1971
    GROUP BY nombre
)
SELECT d.nombre,
       d.decada,
       d.anios_completos,
       ROUND(d.tavg_decada, 2)                                                   AS tavg_c,
       ROUND(d.tavg_decada - LAG(d.tavg_decada) OVER (PARTITION BY d.nombre ORDER BY d.decada), 2)
                                                                                 AS cambio_vs_decada_anterior,
       p.tendencia_c_por_decada_1971_hoy
FROM decadas d
JOIN pendiente p USING (nombre)
WHERE d.decada >= 1970
ORDER BY d.nombre, d.decada;

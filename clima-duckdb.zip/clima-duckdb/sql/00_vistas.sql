-- =====================================================================
-- 00_vistas.sql
-- Registro de los archivos como tablas virtuales (VIEW) + limpieza.
-- Nada se copia a una base de datos: DuckDB lee los CSV en cada consulta.
-- =====================================================================

-- 1) Tabla virtual cruda: todos los CSV de data/ como una sola tabla.
--    union_by_name=true alinea columnas aunque cada estación traiga
--    variables distintas (p. ej. Sídney no tiene TAVG).
CREATE OR REPLACE VIEW clima_crudo AS
SELECT *
FROM read_csv('data/*.csv', union_by_name = true, header = true);

-- 2) Tabla virtual limpia. Reglas de limpieza:
--    a) GHCN guarda temperaturas en DÉCIMAS de °C y lluvia en DÉCIMAS de mm.
--    b) Los atributos tienen el formato "MFLAG,QFLAG,SFLAG". Si QFLAG (calidad)
--       no está vacío, el dato NO pasó el control de calidad de NOAA -> NULL.
--    c) Valores físicamente imposibles (fuera de -60 °C a 60 °C) -> NULL.
--    d) Días con TMAX < TMIN son inconsistentes -> ambos NULL.
--    e) Si falta TAVG se imputa como (TMAX + TMIN) / 2 cuando ambos existen.
--    f) Se excluye el año en curso: sus datos son provisionales e incompletos
--       (p. ej. CDMX 2026 trae una media de ~24 °C, unos 6 °C sobre lo normal).
CREATE OR REPLACE VIEW clima AS
WITH base AS (
    SELECT
        STATION                                           AS estacion,
        NAME                                              AS nombre,
        DATE                                              AS fecha,
        TRY_CAST(TRIM(CAST(TMAX AS VARCHAR)) AS INTEGER)  AS tmax_raw,
        TRY_CAST(TRIM(CAST(TMIN AS VARCHAR)) AS INTEGER)  AS tmin_raw,
        TRY_CAST(TRIM(CAST(TAVG AS VARCHAR)) AS INTEGER)  AS tavg_raw,
        TRY_CAST(TRIM(CAST(PRCP AS VARCHAR)) AS INTEGER)  AS prcp_raw,
        COALESCE(split_part(TMAX_ATTRIBUTES, ',', 2), '') AS q_tmax,
        COALESCE(split_part(TMIN_ATTRIBUTES, ',', 2), '') AS q_tmin,
        COALESCE(split_part(TAVG_ATTRIBUTES, ',', 2), '') AS q_tavg,
        COALESCE(split_part(PRCP_ATTRIBUTES, ',', 2), '') AS q_prcp
    FROM clima_crudo
    WHERE STATION IS NOT NULL
      AND DATE < date_trunc('year', current_date)                       -- (f)
),
convertido AS (
    SELECT
        estacion, nombre, fecha,
        CASE WHEN q_tmax = '' AND tmax_raw BETWEEN -600 AND 600 THEN tmax_raw / 10.0 END AS tmax,  -- (a)(b)(c)
        CASE WHEN q_tmin = '' AND tmin_raw BETWEEN -600 AND 600 THEN tmin_raw / 10.0 END AS tmin,
        CASE WHEN q_tavg = '' AND tavg_raw BETWEEN -600 AND 600 THEN tavg_raw / 10.0 END AS tavg_obs,
        CASE WHEN q_prcp = '' AND prcp_raw >= 0                 THEN prcp_raw / 10.0 END AS prcp_mm
    FROM base
),
consistente AS (
    SELECT
        estacion, nombre, fecha, tavg_obs, prcp_mm,
        CASE WHEN tmax >= tmin OR tmin IS NULL OR tmax IS NULL THEN tmax END AS tmax,      -- (d)
        CASE WHEN tmax >= tmin OR tmin IS NULL OR tmax IS NULL THEN tmin END AS tmin
    FROM convertido
)
SELECT
    estacion,
    nombre,
    fecha,
    year(fecha)                                                AS anio,
    month(fecha)                                               AS mes,
    tmax,
    tmin,
    COALESCE(tavg_obs, (tmax + tmin) / 2)                      AS tavg,             -- (e)
    tavg_obs IS NULL AND tmax IS NOT NULL AND tmin IS NOT NULL AS tavg_imputada,
    prcp_mm
FROM consistente;

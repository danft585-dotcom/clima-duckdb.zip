-- Consulta 5 · FILTRADO COMPLEJO + VENTANAS: días "muy calurosos".
-- Umbral propio de cada estación = percentil 90 de TMAX en 1961-1990.
-- Se cuentan los días por encima del umbral, por década, y se compara
-- la década 1961-1990 contra 1995-2024 (últimos 30 años completos).
WITH umbral AS (
    SELECT nombre, quantile_cont(tmax, 0.90) AS p90_tmax
    FROM clima
    WHERE anio BETWEEN 1961 AND 1990 AND tmax IS NOT NULL
    GROUP BY nombre
),
conteo AS (
    SELECT c.nombre,
           u.p90_tmax,
           CASE WHEN c.anio BETWEEN 1961 AND 1990 THEN '1961-1990'
                WHEN c.anio BETWEEN 1995 AND 2024 THEN '1995-2024' END AS periodo,
           COUNT(c.tmax)                                         AS dias_validos,
           COUNT(*) FILTER (WHERE c.tmax > u.p90_tmax)           AS dias_calurosos
    FROM clima c
    JOIN umbral u USING (nombre)
    WHERE c.tmax IS NOT NULL
      AND (c.anio BETWEEN 1961 AND 1990 OR c.anio BETWEEN 1995 AND 2024)
    GROUP BY ALL
)
PIVOT (
    SELECT nombre,
           ROUND(p90_tmax, 1)                                   AS umbral_p90_c,
           periodo,
           ROUND(365.25 * dias_calurosos / dias_validos, 1)     AS dias_por_anio
    FROM conteo
)
ON periodo
USING first(dias_por_anio)
ORDER BY nombre;

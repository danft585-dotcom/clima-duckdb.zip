# Análisis de datos meteorológicos con DuckDB y SQL

Análisis de series de tiempo diarias de temperatura y precipitación de **5 estaciones de NOAA GHCN-Daily** (Ciudad de México, Nueva York, Madrid, Sídney y Tokio), con **DuckDB como motor analítico embebido**.

Las consultas SQL se ejecutan **directamente sobre los archivos CSV** (y opcionalmente sobre Parquet o sobre la URL de NOAA). No hay servidor de base de datos ni archivo `.duckdb`: DuckDB corre en memoria dentro del proceso de Python.

---

## Estructura del repositorio

```
.
├── analisis.py              # Script principal: registra vistas, ejecuta las consultas, mide tiempos
├── descargar_datos.py       # Descarga los CSV de NOAA a data/
├── sql/
│   ├── 00_vistas.sql        # Tablas virtuales (VIEW) sobre los CSV + limpieza de datos
│   ├── 01_calidad_datos.sql         # Conteos: cobertura y nulos por estación
│   ├── 02_promedios_mensuales.sql   # Promedios: climatología mensual 1991-2020 (PIVOT)
│   ├── 03_extremos_historicos.sql   # Máximos/mínimos históricos con fecha (arg_max/arg_min)
│   ├── 04_tendencia_decadas.sql     # Filtrado complejo: décadas completas, LAG(), regresión
│   ├── 05_dias_calurosos.sql        # Filtrado complejo: días > percentil 90 (FILTER, PIVOT)
│   └── 06_anios_extremos.sql        # Ranking: top 3 años más cálidos (RANK + QUALIFY)
├── resultados/
│   └── resultados.md        # Salida completa del último análisis (se regenera)
├── data/                    # CSV descargados (ignorados por git)
├── requirements.txt
└── .gitignore
```

## Cómo replicar el análisis

Requisitos: **Python 3.9 o superior** y conexión a internet.

```bash
# 1. Clonar el repositorio
git clone https://github.com/<tu-usuario>/clima-duckdb.git
cd clima-duckdb

# 2. Crear un entorno virtual e instalar las dependencias
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. Descargar los datos (5 CSV, ~33 MB en total)
python descargar_datos.py

# 4. Ejecutar el análisis
python analisis.py
```

El script imprime cada tabla en la consola con su tiempo de ejecución y guarda todo en `resultados/resultados.md`.

### Opciones

| Comando | Qué hace |
|---|---|
| `python analisis.py` | Las 6 consultas + benchmark CSV vs Parquet |
| `python analisis.py --sin-benchmark` | Solo las consultas |
| `python analisis.py --remoto` | **Sin descargar nada**: DuckDB lee los CSV directamente desde la URL de NOAA por HTTPS |

### Alternativa: usar solo SQL (CLI de DuckDB)

Las consultas están en archivos `.sql` independientes, así que también pueden ejecutarse desde el [CLI de DuckDB](https://duckdb.org/docs/installation/) desde la raíz del repo:

```bash
duckdb -c ".read sql/00_vistas.sql" -c ".read sql/02_promedios_mensuales.sql"
```

## Cómo se usa DuckDB

1. **Archivo como tabla virtual.** `sql/00_vistas.sql` crea la vista `clima_crudo` con `read_csv('data/*.csv', union_by_name = true)`. El *glob* une los 5 archivos aunque cada estación tenga columnas distintas. No se copia nada: cada consulta lee los CSV.
2. **Limpieza en una segunda vista (`clima`):**
   - Conversión de unidades: GHCN guarda las temperaturas en décimas de °C y la lluvia en décimas de mm.
   - **Nulos por control de calidad**: si el `QFLAG` de NOAA (2.º campo de `*_ATTRIBUTES`) no está vacío, el valor pasa a `NULL`.
   - Valores fuera de -60 °C a 60 °C, y días con TMAX < TMIN, pasan a `NULL`.
   - **Imputación**: si falta `TAVG` se usa `(TMAX + TMIN) / 2`.
   - Se excluye el **año en curso**, porque sus datos son provisionales (ver hallazgo 6).
3. **Motor en memoria**: `duckdb.connect(":memory:")`. El único archivo que se escribe es `data/clima.parquet` en el benchmark, que es un archivo de datos y no una base de datos, y está en `.gitignore`.

## Resultados

> Datos descargados de NOAA el **24-nov-2026**; DuckDB 2.0.1. Si los descargás otro día los números pueden variar un poco, porque NOAA actualiza los archivos. La salida completa está en [`resultados/resultados.md`](resultados/resultados.md).

### Tiempos de respuesta

Medidos en un contenedor Linux de la nube con 183 436 registros diarios. Cada consulta incluye la lectura y limpieza de los 33 MB de CSV.

| Consulta | Tiempo |
|---|---|
| Registro de vistas + primer conteo | ~1.0 s |
| 1 · Calidad de datos (conteos) | 0.56 s |
| 2 · Climatología mensual (promedios + PIVOT) | 1.10 s |
| 3 · Extremos históricos (arg_max / arg_min) | 0.61 s |
| 4 · Tendencia por década (LAG + regresión) | 0.61 s |
| 5 · Días muy calurosos (percentiles + FILTER) | 2.93 s |
| 6 · Top 3 años más cálidos (QUALIFY) | 0.67 s |

**CSV vs Parquet** (misma agregación mensual, mejor de 3 corridas):

| Formato | Tamaño | Tiempo |
|---|---|---|
| CSV (vista con limpieza) | 32.8 MB | 543 ms |
| Parquet (zstd) | 1.0 MB | 6 ms |

Convertir a Parquet tomó 0.64 s. Después las consultas fueron **~90× más rápidas** y el archivo pesa **~30× menos**, porque Parquet es columnar, está comprimido y ya trae los tipos. En modo `--remoto` el registro tarda ~2.9 s y cada consulta entre 0.75 y 2.9 s, porque hay que bajar los datos por la red en cada lectura.

### Climatología mensual 1991-2020 (°C, temperatura media)

| Estación | Ene | Feb | Mar | Abr | May | Jun | Jul | Ago | Sep | Oct | Nov | Dic |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Ciudad de México | 14.6 | 16.9 | 18.3 | 19.7 | **19.9** | 19.1 | 17.6 | 17.8 | 17.3 | 16.7 | 15.9 | 15.3 |
| Madrid | 5.5 | 6.9 | 10.3 | 12.9 | 17.2 | 22.8 | **26.2** | 25.7 | 20.7 | 15.0 | 9.3 | 6.0 |
| Nueva York | 0.9 | 2.1 | 6.0 | 12.0 | 17.3 | 22.2 | **25.2** | 24.5 | 20.6 | 14.4 | 8.9 | 3.9 |
| Sídney | **23.5** | 23.4 | 22.1 | 19.5 | 16.6 | 14.1 | 13.4 | 14.5 | 16.9 | 18.9 | 20.4 | 22.1 |
| Tokio | 6.1 | 6.8 | 9.9 | 14.9 | 19.4 | 22.5 | 26.4 | **27.5** | 24.0 | 18.7 | 13.4 | 8.6 |

### Extremos históricos por estación

| Estación | Máx. histórica | Fecha | Mín. histórica | Fecha | Lluvia máx. en un día |
|---|---|---|---|---|---|
| Sídney | 43.4 °C | 2018-01-07 | 2.1 °C | 1932-06-22 | 327.6 mm (1986-08-06) |
| Madrid | 42.7 °C | 2021-08-14 | -15.2 °C | 1945-01-16 | 73.8 mm (2023-10-19) |
| Nueva York | 41.1 °C | 1936-07-09 | -26.1 °C | 1934-02-09 | 210.3 mm (1882-09-23) |
| Tokio | 39.5 °C | 2004-07-20 | -6.3 °C | 1954-01-28 | 371.9 mm (1958-09-26) |
| Ciudad de México | 36.0 °C | 1995-05-24 | -1.4 °C | 1988-01-28 | 162.6 mm (2012-06-28) |

### Calentamiento: tendencia y días calurosos

| Estación | Tendencia 1971-2025 (°C/década) | Días > P90 por año, 1961-1990 | Días > P90 por año, 1995-2024 | Año más cálido (anomalía vs 1991-2020) |
|---|---|---|---|---|
| Madrid | **+0.49** | 36.2 | 52.2 | 2022 (+1.73 °C) |
| Ciudad de México | +0.41 | 36.6* | **70.5** | 2024 (+2.12 °C) |
| Tokio | +0.28 | 36.4 | 47.9 | 2024 (+1.18 °C) |
| Sídney | +0.24 | 35.3 | 47.8 | 2016 (+0.88 °C) |
| Nueva York | +0.22 | 34.6 | 31.9 | 2023 (+1.23 °C) |

\* En CDMX la serie empieza en 1973 y tiene huecos, así que el período base en la práctica cubre de 1977 a 1990.

## Hallazgos principales

1. **Las 5 ciudades se calientan.** La pendiente de la regresión lineal es positiva en todas, desde +0.22 °C/década en Nueva York hasta +0.49 °C/década en Madrid. En Madrid eso equivale a unos 2.6 °C en 54 años.
2. **Los años recientes dominan los récords.** En 4 de las 5 estaciones, al menos 2 de los 3 años más cálidos son de 2019 o después. 2024 fue el año más cálido medido en Ciudad de México y en Tokio, y 2023 en Nueva York.
3. **Los días muy calurosos se multiplicaron.** Por definición, el umbral del percentil 90 de 1961-1990 se supera unos 36 días por año. En 1995-2024 se superó 70 días/año en CDMX (casi el doble), 52 en Madrid y unos 48 en Tokio y Sídney. Nueva York es la excepción: allí los días muy calurosos no aumentaron. Su calentamiento está en los inviernos (dic-feb: +0.31 °C/década en máximas y +0.41 °C/década en mínimas desde 1971), mientras que la máxima de verano casi no cambió (+0.02 °C/década).
4. **Clima de montaña tropical vs. clima templado.** CDMX tiene la menor amplitud anual (14.6–19.9 °C). Su mes más cálido es mayo, antes de la temporada de lluvias, mientras que en las ciudades templadas del hemisferio norte es julio o agosto. Sídney muestra el ciclo invertido del hemisferio sur.
5. **Muchos récords absolutos son recientes**: Sídney (2018) y Madrid (2021).
6. **La calidad de datos importa.** Madrid y Tokio tienen unos 3 200 días sin TMAX válido, y CDMX casi no tiene datos entre 2000 y 2004. Los datos provisionales de CDMX de 2026 traen una media de unos 24 °C, unos 6 °C por encima de lo normal, y máximos de 41 °C que la ciudad nunca registró. Sin la regla que excluye el año en curso, ese error habría generado un récord falso.

## Limitaciones

- Cada estación es un solo punto y puede estar afectada por la isla de calor urbana o por cambios de instrumento o ubicación.
- La serie de Sídney termina en ago-2020 y la de Tokio en ago-2025 en el archivo de NOAA.
- `TAVG` imputada como (TMAX+TMIN)/2 no es idéntica a la media horaria que reportan algunas estaciones.

## Fuente de datos

Menne, M. J. et al. *Global Historical Climatology Network – Daily (GHCN-Daily)*, NOAA National Centers for Environmental Information.
<https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily>

| ID GHCN | Estación |
|---|---|
| MXM00076680 | Mexico City (Aeropuerto), MX |
| USW00094728 | New York Central Park, US |
| SPE00120278 | Madrid Barajas, ES |
| ASN00066062 | Sydney Observatory Hill, AU |
| JA000047662 | Tokyo, JP |

"""
Descarga los CSV diarios de NOAA GHCN-Daily (Global Historical Climatology
Network) para un conjunto de estaciones y los guarda en la carpeta data/.

Fuente: https://www.ncei.noaa.gov/data/global-historical-climatology-network-daily/access/

Uso:
    python descargar_datos.py
"""
from pathlib import Path
import urllib.request

BASE_URL = "https://www.ncei.noaa.gov/data/global-historical-climatology-network-daily/access/"

# ID GHCN -> descripción
ESTACIONES = {
    "MXM00076680": "Ciudad de México (Aeropuerto), México",
    "USW00094728": "Nueva York (Central Park), EE. UU.",
    "SPE00120278": "Madrid (Barajas), España",
    "ASN00066062": "Sídney (Observatory Hill), Australia",
    "JA000047662": "Tokio, Japón",
}

DATA_DIR = Path(__file__).parent / "data"


def main() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    for station_id, nombre in ESTACIONES.items():
        destino = DATA_DIR / f"{station_id}.csv"
        url = f"{BASE_URL}{station_id}.csv"
        print(f"Descargando {nombre:<40} -> {destino.name}")
        urllib.request.urlretrieve(url, destino)
        print(f"   {destino.stat().st_size / 1_048_576:.1f} MB")
    print("\nListo. Ahora ejecutá: python analisis.py")


if __name__ == "__main__":
    main()

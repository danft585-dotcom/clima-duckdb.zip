"""
Análisis de datos meteorológicos (NOAA GHCN-Daily) con DuckDB.

* DuckDB corre embebido y EN MEMORIA: no se crea ningún archivo .duckdb.
* Los CSV se consultan directamente con read_csv() a través de vistas.
* Las consultas viven en sql/ para poder correrlas también desde el CLI.

Uso:
    python analisis.py                 # análisis completo + benchmark CSV vs Parquet
    python analisis.py --sin-benchmark # solo las consultas
    python analisis.py --remoto        # lee los CSV directo desde la URL de NOAA
"""
from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

import duckdb

from descargar_datos import BASE_URL, ESTACIONES

ROOT = Path(__file__).parent
SQL_DIR = ROOT / "sql"
RESULTADOS = ROOT / "resultados"

CONSULTAS = [
    ("01_calidad_datos.sql", "Cobertura y calidad de datos (conteos)"),
    ("02_promedios_mensuales.sql", "Climatología mensual 1991-2020 (°C)"),
    ("03_extremos_historicos.sql", "Máximos y mínimos históricos por estación"),
    ("04_tendencia_decadas.sql", "Temperatura media por década y tendencia"),
    ("05_dias_calurosos.sql", "Días muy calurosos por año (> P90 de 1961-1990)"),
    ("06_anios_extremos.sql", "Top 3 años más cálidos por estación"),
]


def a_markdown(columnas: list[str], filas: list[tuple]) -> str:
    def fmt(v):
        if v is None:
            return ""
        if isinstance(v, float):
            return f"{v:g}"
        return str(v)

    lineas = ["| " + " | ".join(columnas) + " |",
              "|" + "|".join("---" for _ in columnas) + "|"]
    lineas += ["| " + " | ".join(fmt(v) for v in fila) + " |" for fila in filas]
    return "\n".join(lineas)


def ejecutar(con: duckdb.DuckDBPyConnection, sql: str):
    t0 = time.perf_counter()
    rel = con.execute(sql)
    filas = rel.fetchall()
    columnas = [d[0] for d in rel.description]
    return columnas, filas, time.perf_counter() - t0


def benchmark_csv_vs_parquet(con: duckdb.DuckDBPyConnection) -> str:
    """Convierte los CSV a Parquet (archivo de datos, no base de datos) y
    compara el tiempo de una misma agregación sobre ambos formatos."""
    parquet = ROOT / "data" / "clima.parquet"
    t0 = time.perf_counter()
    con.execute(f"""
        COPY (SELECT estacion, nombre, fecha, anio, mes, tmax, tmin, tavg, prcp_mm FROM clima)
        TO '{parquet.as_posix()}' (FORMAT parquet, COMPRESSION zstd)
    """)
    t_conv = time.perf_counter() - t0

    q_csv = """
        SELECT nombre, mes, AVG(tavg), MAX(tmax), MIN(tmin)
        FROM clima GROUP BY ALL
    """
    q_parquet = f"""
        SELECT nombre, mes, AVG(tavg), MAX(tmax), MIN(tmin)
        FROM read_parquet('{parquet.as_posix()}') GROUP BY ALL
    """
    tiempos = {}
    for etiqueta, q in (("CSV (vista con limpieza)", q_csv), ("Parquet", q_parquet)):
        corridas = []
        for _ in range(3):
            *_, t = ejecutar(con, q)
            corridas.append(t)
        tiempos[etiqueta] = min(corridas)

    tam_csv = sum(p.stat().st_size for p in (ROOT / "data").glob("*.csv"))
    tam_pq = parquet.stat().st_size
    filas = [
        ("CSV (vista con limpieza)", f"{tam_csv / 1_048_576:.1f}", f"{tiempos['CSV (vista con limpieza)'] * 1000:.0f}"),
        ("Parquet", f"{tam_pq / 1_048_576:.1f}", f"{tiempos['Parquet'] * 1000:.0f}"),
    ]
    md = a_markdown(["Formato", "Tamaño (MB)", "Agregación mensual (ms, mejor de 3)"], filas)
    md += (f"\n\nConversión CSV → Parquet: {t_conv * 1000:.0f} ms. "
           f"Parquet es {tiempos['CSV (vista con limpieza)'] / tiempos['Parquet']:.0f}× más rápido "
           f"y ocupa {tam_csv / tam_pq:.0f}× menos.")
    return md


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sin-benchmark", action="store_true",
                        help="No ejecutar la comparación CSV vs Parquet")
    parser.add_argument("--remoto", action="store_true",
                        help="Leer los CSV directamente desde NOAA por HTTPS (sin descargar)")
    args = parser.parse_args()

    # Rutas relativas de las vistas (data/*.csv) se resuelven desde la raíz.
    os.chdir(ROOT)
    (ROOT / "data").mkdir(exist_ok=True)

    vistas_sql = (SQL_DIR / "00_vistas.sql").read_text(encoding="utf-8")
    if args.remoto:
        urls = ", ".join(f"'{BASE_URL}{sid}.csv'" for sid in ESTACIONES)
        vistas_sql = vistas_sql.replace("'data/*.csv'", f"[{urls}]")
        args.sin_benchmark = True  # el benchmark compara archivos locales
        print("Modo remoto: DuckDB leerá los CSV por HTTPS desde NOAA.")
    elif not list((ROOT / "data").glob("*.csv")):
        raise SystemExit("No hay CSV en data/. Ejecutá primero: python descargar_datos.py "
                         "(o usá --remoto)")

    # Conexión en memoria: no se escribe ninguna base de datos en disco.
    con = duckdb.connect(database=":memory:")

    t0 = time.perf_counter()
    con.execute(vistas_sql)
    total_filas = con.execute("SELECT COUNT(*) FROM clima").fetchone()[0]
    t_carga = time.perf_counter() - t0

    informe = [
        "# Resultados del análisis",
        "",
        f"DuckDB {duckdb.__version__} · {total_filas:,} registros diarios · "
        f"registro de vistas + primer conteo: {t_carga * 1000:.0f} ms",
        "",
        "| Consulta | Tiempo (ms) | Filas |",
        "|---|---|---|",
    ]
    secciones = []

    print(f"\nDuckDB {duckdb.__version__} — {total_filas:,} registros diarios "
          f"({t_carga * 1000:.0f} ms)\n")

    for archivo, titulo in CONSULTAS:
        sql = (SQL_DIR / archivo).read_text(encoding="utf-8")
        columnas, filas, t = ejecutar(con, sql)
        print(f"=== {titulo}  [{t * 1000:.0f} ms] ===")
        con.sql(sql).show(max_width=200, max_rows=60)
        informe.append(f"| {titulo} (`{archivo}`) | {t * 1000:.0f} | {len(filas)} |")
        secciones += [f"## {titulo}", "", a_markdown(columnas, filas), ""]

    informe += [""] + secciones

    if not args.sin_benchmark:
        print("=== Benchmark CSV vs Parquet ===")
        md = benchmark_csv_vs_parquet(con)
        print(md, "\n")
        informe += ["## Benchmark CSV vs Parquet", "", md, ""]

    RESULTADOS.mkdir(exist_ok=True)
    salida = RESULTADOS / "resultados.md"
    salida.write_text("\n".join(informe), encoding="utf-8")
    print(f"Resultados guardados en {salida.relative_to(ROOT)}")


if __name__ == "__main__":
    main()

# Resultados del análisis

DuckDB 2.0.1 · 183,436 registros diarios · registro de vistas + primer conteo: 1116 ms

| Consulta | Tiempo (ms) | Filas |
|---|---|---|
| Cobertura y calidad de datos (conteos) (`01_calidad_datos.sql`) | 640 | 5 |
| Climatología mensual 1991-2020 (°C) (`02_promedios_mensuales.sql`) | 1261 | 5 |
| Máximos y mínimos históricos por estación (`03_extremos_historicos.sql`) | 673 | 5 |
| Temperatura media por década y tendencia (`04_tendencia_decadas.sql`) | 681 | 22 |
| Días muy calurosos por año (> P90 de 1961-1990) (`05_dias_calurosos.sql`) | 3406 | 5 |
| Top 3 años más cálidos por estación (`06_anios_extremos.sql`) | 689 | 15 |

## Cobertura y calidad de datos (conteos)

| nombre | desde | hasta | dias_registrados | tmax_validos | tmax_nulos | pct_tavg_disponible | tavg_imputadas |
|---|---|---|---|---|---|---|---|
| SYDNEY OBSERVATORY HILL, AS | 1858-07-01 | 2020-08-31 | 59232 | 59025 | 207 | 98.8 | 58528 |
| NY CITY CENTRAL PARK, NY US | 1869-01-01 | 2025-12-31 | 57343 | 57302 | 41 | 99.9 | 54626 |
| MADRID BARAJAS, SP | 1945-01-01 | 2025-12-31 | 27541 | 24333 | 3208 | 88.4 | 5131 |
| TOKYO, JA | 1951-01-01 | 2025-08-24 | 26884 | 23696 | 3188 | 100 | 827 |
| MEXICO CITY, MX | 1973-01-02 | 2025-11-30 | 12436 | 10531 | 1905 | 98.5 | 330 |

## Climatología mensual 1991-2020 (°C)

| nombre | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| MADRID BARAJAS, SP | 5.5 | 6.9 | 10.3 | 12.9 | 17.2 | 22.8 | 26.2 | 25.7 | 20.7 | 15 | 9.3 | 6 |
| MEXICO CITY, MX | 14.6 | 16.9 | 18.3 | 19.7 | 19.9 | 19.1 | 17.6 | 17.8 | 17.3 | 16.7 | 15.9 | 15.3 |
| NY CITY CENTRAL PARK, NY US | 0.9 | 2.1 | 6 | 12 | 17.3 | 22.2 | 25.2 | 24.5 | 20.6 | 14.4 | 8.9 | 3.9 |
| SYDNEY OBSERVATORY HILL, AS | 23.5 | 23.4 | 22.1 | 19.5 | 16.6 | 14.1 | 13.4 | 14.5 | 16.9 | 18.9 | 20.4 | 22.1 |
| TOKYO, JA | 6.1 | 6.8 | 9.9 | 14.9 | 19.4 | 22.5 | 26.4 | 27.5 | 24 | 18.7 | 13.4 | 8.6 |

## Máximos y mínimos históricos por estación

| nombre | record_max_c | fecha_record_max | record_min_c | fecha_record_min | lluvia_max_dia_mm | fecha_lluvia_max |
|---|---|---|---|---|---|---|
| SYDNEY OBSERVATORY HILL, AS | 43.4 | 2018-01-07 | 2.1 | 1932-06-22 | 327.6 | 1986-08-06 |
| MADRID BARAJAS, SP | 42.7 | 2021-08-14 | -15.2 | 1945-01-16 | 73.8 | 2023-10-19 |
| NY CITY CENTRAL PARK, NY US | 41.1 | 1936-07-09 | -26.1 | 1934-02-09 | 210.3 | 1882-09-23 |
| TOKYO, JA | 39.5 | 2004-07-20 | -6.3 | 1954-01-28 | 371.9 | 1958-09-26 |
| MEXICO CITY, MX | 36 | 1995-05-24 | -1.4 | 1988-01-28 | 162.6 | 2012-06-28 |

## Temperatura media por década y tendencia

| nombre | decada | anios_completos | tavg_c | cambio_vs_decada_anterior | tendencia_c_por_decada_1971_hoy |
|---|---|---|---|---|---|
| MADRID BARAJAS, SP | 1970 | 10 | 13.44 |  | 0.49 |
| MADRID BARAJAS, SP | 1980 | 10 | 14.05 | 0.61 | 0.49 |
| MADRID BARAJAS, SP | 1990 | 10 | 14.64 | 0.58 | 0.49 |
| MADRID BARAJAS, SP | 2000 | 10 | 14.57 | -0.07 | 0.49 |
| MADRID BARAJAS, SP | 2010 | 10 | 15.41 | 0.85 | 0.49 |
| MEXICO CITY, MX | 1990 | 9 | 17.32 |  | 0.41 |
| MEXICO CITY, MX | 2010 | 8 | 17.5 | 0.18 | 0.41 |
| NY CITY CENTRAL PARK, NY US | 1970 | 10 | 12.57 |  | 0.22 |
| NY CITY CENTRAL PARK, NY US | 1980 | 10 | 12.87 | 0.31 | 0.22 |
| NY CITY CENTRAL PARK, NY US | 1990 | 10 | 13.18 | 0.31 | 0.22 |
| NY CITY CENTRAL PARK, NY US | 2000 | 10 | 12.97 | -0.21 | 0.22 |
| NY CITY CENTRAL PARK, NY US | 2010 | 10 | 13.49 | 0.52 | 0.22 |
| SYDNEY OBSERVATORY HILL, AS | 1970 | 10 | 18.15 |  | 0.24 |
| SYDNEY OBSERVATORY HILL, AS | 1980 | 10 | 18.35 | 0.2 | 0.24 |
| SYDNEY OBSERVATORY HILL, AS | 1990 | 10 | 18.29 | -0.06 | 0.24 |
| SYDNEY OBSERVATORY HILL, AS | 2000 | 10 | 18.79 | 0.5 | 0.24 |
| SYDNEY OBSERVATORY HILL, AS | 2010 | 10 | 19.14 | 0.35 | 0.24 |
| TOKYO, JA | 1970 | 10 | 15.76 |  | 0.28 |
| TOKYO, JA | 1980 | 10 | 15.64 | -0.13 | 0.28 |
| TOKYO, JA | 1990 | 10 | 16.48 | 0.85 | 0.28 |
| TOKYO, JA | 2000 | 9 | 16.7 | 0.21 | 0.28 |
| TOKYO, JA | 2010 | 10 | 16.57 | -0.12 | 0.28 |

## Días muy calurosos por año (> P90 de 1961-1990)

| nombre | umbral_p90_c | 1961-1990 | 1995-2024 |
|---|---|---|---|
| MADRID BARAJAS, SP | 33 | 36.2 | 52.2 |
| MEXICO CITY, MX | 27.8 | 36.6 | 70.5 |
| NY CITY CENTRAL PARK, NY US | 30 | 34.6 | 31.9 |
| SYDNEY OBSERVATORY HILL, AS | 27.6 | 35.3 | 47.8 |
| TOKYO, JA | 30.8 | 36.4 | 47.9 |

## Top 3 años más cálidos por estación

| nombre | puesto | anio | tavg_c | anomalia_c |
|---|---|---|---|---|
| MADRID BARAJAS, SP | 1 | 2022 | 16.65 | 1.73 |
| MADRID BARAJAS, SP | 2 | 2023 | 16.09 | 1.17 |
| MADRID BARAJAS, SP | 3 | 2024 | 16.02 | 1.11 |
| MEXICO CITY, MX | 1 | 2024 | 19.57 | 2.12 |
| MEXICO CITY, MX | 2 | 2023 | 19.4 | 1.94 |
| MEXICO CITY, MX | 3 | 2019 | 19.07 | 1.62 |
| NY CITY CENTRAL PARK, NY US | 1 | 2023 | 14.45 | 1.23 |
| NY CITY CENTRAL PARK, NY US | 2 | 2024 | 14.43 | 1.21 |
| NY CITY CENTRAL PARK, NY US | 3 | 1998 | 14.14 | 0.92 |
| SYDNEY OBSERVATORY HILL, AS | 1 | 2016 | 19.63 | 0.88 |
| SYDNEY OBSERVATORY HILL, AS | 2 | 2019 | 19.54 | 0.78 |
| SYDNEY OBSERVATORY HILL, AS | 3 | 2017 | 19.45 | 0.69 |
| TOKYO, JA | 1 | 2024 | 17.74 | 1.18 |
| TOKYO, JA | 2 | 2023 | 17.73 | 1.17 |
| TOKYO, JA | 3 | 2004 | 17.35 | 0.79 |

## Benchmark CSV vs Parquet

| Formato | Tamaño (MB) | Agregación mensual (ms, mejor de 3) |
|---|---|---|
| CSV (vista con limpieza) | 32.8 | 576 |
| Parquet | 1.0 | 6 |

Conversión CSV → Parquet: 750 ms. Parquet es 91× más rápido y ocupa 31× menos.
